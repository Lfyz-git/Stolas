# HTTP API и CLI

Все запросы, включая `/healthz`, требуют `Authorization: Bearer <STOLAS_API_TOKEN>`.
Токен создаёт установщик и сохраняет в `.env`. API не принимает произвольные
серверы или команды от клиента — только запускает измерение по конфигурации агента.

| Метод и путь | Результат |
| --- | --- |
| GET `/healthz` | `{"status":"ready"}`; готовность процесса, без измерения |
| POST `/v1/tests` | Выполнить один цикл; JSON результата, HTTP 200 даже при низкой скорости/ошибке WAN |
| GET `/v1/results/latest` | Последний сохранённый цикл; 404, если результатов ещё нет |
| GET `/v1/results` | `{"results":[...]}` — до 100 последних циклов, новые первыми |
| GET `/v1/summary/daily` | Сводка сохранённых данных за предыдущие 24 часа; без нового измерения |

POST не содержит тела. Не отправляйте Transfer-Encoding или ненулевой Content-Length.
`401` — неверный токен, `400` — запрещённое тело, `409` — уже идёт тест,
`429` — ещё не истёк `min_interval`, `500` — внутренняя ошибка.
Не повторяйте POST автоматически после сетевого таймаута: цикл мог выполниться.
Сначала прочитайте последний результат. HTTP-клиенту нужен таймаут больше `cycle_timeout`.

```sh
curl -fsS -X POST -H "Authorization: Bearer $STOLAS_API_TOKEN" \
  --max-time 300 "http://$STOLAS_LISTEN:$STOLAS_PORT/v1/tests"
```

## JSON результата

Схема версии 1 сохраняется. `id` — идентификатор цикла; в логах он называется `test_id`.
`primary` содержит первый полноценный замер, `confirmation` — независимое подтверждение.
`attempts` хранит все попытки, отдельные download/upload и причины ошибок.
Скорость — Mbps; iperf TCP retransmits не является потерями UDP.

| status | Значение |
| --- | --- |
| `ok` | Скорость выше заданных порогов |
| `low_confirmed` | Низкая скорость в одном направлении подтверждена другим адресом |
| `low_unconfirmed` | Низкая скорость без независимого подтверждения |
| `server_disagreement` | Серверы не подтвердили снижение в одном направлении |
| `route_blocked` | Проверка WAN остановила измерение |
| `unavailable` | Полноценного замера нет |

`wan_alert` — данные для внешнего потребителя, а не отправка уведомления.
Он устанавливается только при подтверждённом снижении с согласованными
проверками WAN. При смешанных IP он остаётся false.

`attempts[].route_checks` хранит сведения HTTPS-проверки: `verified`, `verification_status`,
`allow_measurement`, `egress_verified` и ответы `sources` с IP либо кодом ошибки.
При раздельной маршрутизации `verification_status="mixed"`, `verified=false`,
`allow_measurement=true`; `warnings` содержит `mixed_routing`.
Само измерение при этом может иметь обычный `status="ok"`.
`egress_verified=false` означает, что внешний маршрут iperf3 не подтверждён.
[Правила проверки канала](CONFIGURATION.md#проверка-канала).

## Команда установленного приложения

```sh
./stolas run
./stolas run --json
./stolas history
./stolas logs
./stolas help
```

Без `--json` команда run показывает краткий результат и предупреждения.
С `--json` сохраняется контракт stdout JSON / stderr события.

## CLI

```sh
python3 -m agent validate --config config/local.json
python3 -m agent run --config config/local.json --data ./data
python3 -m agent history --config config/local.json --data ./data
```

Для запуска в ОС нужны Python 3.10+, iperf3 и iproute2. `serve` запускает HTTP API;
`schedule` сохранён для совместимости и выполняет цикл каждые 3 часа.
`STOLAS_CONFIG` и `STOLAS_DATA_DIR` заменяют соответствующие аргументы.

CLI `run`: код 0 — `ok`, 2 — измерение завершено с другим статусом,
1 — запуск/хранилище/конфигурация недоступны. stdout содержит JSON результата,
stderr — диагностические события. stderr нельзя объединять со stdout при разборе JSON.

## Сетевой доступ

На одной машине используйте loopback. Для клиента в доверенной Docker/VPN-сети
выберите конкретный адрес хоста в мастере настройки API; `0.0.0.0` не предлагается.
Для доступа через недоверенную сеть нужен настроенный вами HTTPS reverse proxy
и ограничение доступа. Stolas не меняет firewall, DNS, TLS или маршрутизацию.
